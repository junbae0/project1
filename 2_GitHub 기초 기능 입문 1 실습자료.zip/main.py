import max_profit as mp
import prime_number as pn

if __name__ == '__main__':
    pn.is_prime_number(1)
    pn.is_prime_number(13)
    pn.is_prime_number(24)
    pn.is_prime_number(31)
    pn.is_prime_number(45)
    pn.is_prime_number(97)
